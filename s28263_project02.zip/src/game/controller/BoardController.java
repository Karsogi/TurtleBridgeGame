package game.controller;

import game.event.*;
import game.model.BoardModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.concurrent.atomic.AtomicInteger;

public final class BoardController implements GameEventListener {

    private final BoardModel model;
    private final AtomicInteger pendingDx = new AtomicInteger(0); // -1 / 0 / +1

    public BoardController(BoardModel model, Component focusTarget) {
        this.model = model;
        focusTarget.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_A -> pendingDx.set(-1);
                    case KeyEvent.VK_D -> pendingDx.set(+1);
                    case KeyEvent.VK_R -> {
                        model.reset();
                        EventBus.fire(new ResetEvent(this));
                    }
                    case KeyEvent.VK_S -> EventBus.fire(new StartEvent(this));
                    case KeyEvent.VK_P -> model.incScore();
                }
            }
        });
        EventBus.addGameEventListener(this);
    }

    @Override
    public void handle(GameEvent e) {
        if (e instanceof TickEvent) {
            SwingUtilities.invokeLater(() -> {
                int dx = pendingDx.getAndSet(0);
                if (dx != 0) model.moveHero(dx);
                model.updateFish();
                model.spawnFishesIfNeeded();
                model.updateTurtles();
                model.updateHero();
            });
        } else if (e instanceof ResetEvent) {
            pendingDx.set(0);
        }
    }
}

