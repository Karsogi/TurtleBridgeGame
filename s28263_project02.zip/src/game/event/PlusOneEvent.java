package game.event;

public class PlusOneEvent extends GameEvent {
    public PlusOneEvent(Object src) { super(src); }
}
