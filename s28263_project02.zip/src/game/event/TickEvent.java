package game.event;

public class TickEvent extends GameEvent {
    public TickEvent(Object s) {
        super(s);
    }
}
