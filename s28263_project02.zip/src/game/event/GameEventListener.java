package game.event;

public interface GameEventListener {
    void handle(GameEvent e);
}