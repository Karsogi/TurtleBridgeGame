package game.event;

public class ResetEvent extends GameEvent {
    public ResetEvent(Object src) { super(src); }
}