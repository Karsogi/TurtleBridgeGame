package game.event;

public class StartEvent extends GameEvent {
    public StartEvent(Object src) { super(src); }
}
